The fourth phase in the Lunch List App construction

Adding a database for information persistence.
The database is a SQLite file stored in the app private directory on the device.